import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  Animated,
  TouchableOpacity,
} from 'react-native';

//Konstanten, die die Dauer des Einatmens und Ausatmens in Sekunden festlegen

const BREATH_IN_DURATION = 4; //Sekunden
const BREATH_OUT_DURATION = 6; //Sekunden

//Benutzerdefinierte Hook für die Atmungssteuerung

const useBreathingControl = () => {
  const [breathingIn, setBreathingIn] = useState(true); //Zeigt an, ob der Benutzer gerade einatmet
  const [timer, setTimer] = useState(0); //Ein Timer, der die vergangene Zeit zählt
  const [breathing, setBreathing] = useState(false); //Zeigt an, ob die Atmung aktiv ist (also ob die App gerade in Benutzung ist)
  const backgroundColor = useRef(new Animated.Value(0)).current; //Ein animierter Wert, der für die Hintergrundfarbe verwendet wird
  const animationRef = useRef<Animated.CompositeAnimation | null>(null); //Referenzen für die Atmungsanimation 
  const intervalRef = useRef<NodeJS.Timeout | null>(null); ////Referenzen für die Zeitintervall

//Zwei Funktionen, um die Atmung zu starten bzw. zu stoppen

//wird eine Animation mit Hilfe von Animated.loop und Animated.sequence definiert, die den Hintergrund von weiß zu schwarz wechselt, entsprechend der Ein- und Ausatmung

  const startBreathing = useCallback(() => { //neue Fkt
    setBreathing(true); //Atmung true
    animationRef.current = Animated.loop( //beginn der Animation, so dass es stoppen kann
      Animated.sequence([
        Animated.timing(backgroundColor, { //über eine bestimmte Dauer zu erstellen
          toValue: 1, //ändern Varibale backgrondColor von 0 auf 1
          duration: BREATH_IN_DURATION * 1000,
          useNativeDriver: false,
        }),
        Animated.timing(backgroundColor, {
          toValue: 0,
          duration: BREATH_OUT_DURATION * 1000,
          useNativeDriver: false,
        }),
      ]),
      { iterations: -1 } //Wiederholen von Animation auf unendlich
    );
    animationRef.current.start(); //start
  }, [backgroundColor]);

//wird die Animation gestoppt

  const stopBreathing = useCallback(() => { //neue Fkt
    setBreathing(false); //Atmung false
    if (animationRef.current) { //gibt es eine Aktive Animation?
      animationRef.current.stop(); //wenn ja, stopp
      animationRef.current = null; //Referenz von Animation gelöscht
    }
  }, []);

//Zwei useEffect-Hooks, um Nebeneffekte zu behandeln

//Erste: wenn der breathing-Zustand sich ändert
//Wenn breathing wahr, startet ein Intervall, das den timer-Zustand jede Sekunde um 1 erhöht
//Wenn breathing falsch, stoppt das Intervall und setzt den timer und breathingIn zurück

  useEffect(() => {
    if (breathing) { //wenn true
      intervalRef.current = setInterval(() => { //neue Intervall
        setTimer((prevTimer) => prevTimer + 1); 
      }, 1000); //alle 1000 Millisekunden (1 Sekunde) ausgeführt
    } else { //wenn false
      if (intervalRef.current) {  //wenn ein Intervall existiert
        clearInterval(intervalRef.current);
        intervalRef.current = null;  //Referenz zum Intervall wird gelöscht
      }
      setTimer(0); //Timer zurückgesetzt
      setBreathingIn(true); //Atmung beginnt
      backgroundColor.setValue(0); //backgroundColor zurückgesetzt
    }
    return () => { //Bereinigungsfunktion
      if (intervalRef.current) { //wenn ein Intervall existiert
        clearInterval(intervalRef.current); //stopp
      }
    };
  }, [breathing, backgroundColor]); //Liste der Abhängigkeiten, wenn sich der Wert von breathing oder backgroundColor ändert

//useMemo, um unnötige Neuberechnungen zu vermeiden

  const duration = useMemo(
    () => (breathingIn ? BREATH_IN_DURATION : BREATH_OUT_DURATION),  //BREATH_IN_DURATION zurückgibt, wenn breathingIn true, BREATH_OUT_DURATION, wenn breathingIn false
    [breathingIn]
  );

  const breathingText = useMemo(
    () => (breathingIn ? 'Inhale' : 'Exhale'), //"Inhale" zurück, wenn breathingIn true,  "Exhale" zurück, wenn breathingIn false
    [breathingIn]
  );

  const remainingTime = useMemo(() => duration - timer, [duration, timer]); //Berechnung der verbleibenden Zeit

//Zweite: wenn sich der timer-Zustand ändert
//Wenn timer größer oder gleich der duration -> timer zurücksetzen, breathingIn-Zustand wechseln

  useEffect(() => {
    if (timer >= duration) {
      setTimer(0);
      setBreathingIn(!breathingIn);
    }
  }, [timer, breathingIn, duration]);

  return {
    breathingIn,
    timer,
    breathing,
    startBreathing,
    stopBreathing,
    backgroundColor,
    breathingText,
    duration,
    remainingTime,
  };
};

//Hauptkomponente nutzt die zuvor definierte benutzerdefinierte Hook

//Definieren von Stile (Bildschirmorientierung, das Layout der App, einschließlich des Atemtextes, des Timers und des Start-/Stopp-Knopfs)
//backgroundColor aus useBreathingControl, um die Hintergrundfarbe basierend auf dem Atemzyklus zu ändern

const App = () => {
  const {
    breathing,
    startBreathing,
    stopBreathing,
    backgroundColor,
    breathingText,
    remainingTime,
  } = useBreathingControl();

  const { width, height } = Dimensions.get('window');
  const isLandscape = width > height;

  const textStyle = isLandscape ? styles.landscapeText : styles.portraitText;

  const interpolatedBackgroundColor = backgroundColor.interpolate({
    inputRange: [0, 1],
    outputRange: ['rgba(255, 255, 255, 0.7)', 'rgba(0, 0, 0, 0.7)'],
  });

//Darstellung der Benutzeroberfläche

return (
    <Animated.View
      style={[
        styles.container,
        { backgroundColor: interpolatedBackgroundColor },
      ]}>
            <View style={styles.textContainer}>
        <Text style={textStyle}>{breathingText}</Text>
      </View>
      <View style={styles.breatheTimerContainer}>
          <Text style={styles.counter}>{remainingTime}</Text>
      </View>
      {breathing ? (
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.button} onPress={stopBreathing}>
            <Text style={styles.buttonText}>Stop</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.button} onPress={startBreathing}>
            <Text style={styles.buttonText}>Start</Text>
          </TouchableOpacity>
        </View>
      )}
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textContainer: {
    position: 'absolute',
    top: 0,
    bottom: '70%',  // Positioniert das untere Ende des Textcontainers in der Mitte des Bildschirms
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
  breatheTimerContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FBAF04',
    borderRadius: 100,
    width: 200,
    height: 200,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 16,
    boxShadow: '0 2px 5px rgba(255, 255, 255, 0.7)',
    outline: '1px solid rgba(0, 0, 0, 0.1)',
    elevation: 20,
  },
  buttonContainer: {
    position: 'absolute', 
    bottom: 10,
    width: '100%',
    alignItems: 'center',
    paddingBottom: 20,
  },

  portraitText: {
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    fontFamily: 'Satoshi'
  },
  landscapeText: {
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    fontFamily: 'Satoshi',
  },
  counter: {
    fontSize: 100,
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    fontFamily: 'Satoshi',
  },
  button: {
    backgroundColor: '#1F1F1F',
    borderRadius: 40,
    width: 100,
    height: 60,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 16,
    elevation: 20,
  },
  buttonText: {
    fontSize: 24,
    color: 'white',
    fontFamily: 'Satoshi',
    //fontWeight: 'bold',
  },
});

export default App;
