import * as React from 'react';
import BreathingTimer from './components/BreathingTimer.tsx';
const App = () => {
  return (
    <BreathingTimer />
  );
};

export default App;
