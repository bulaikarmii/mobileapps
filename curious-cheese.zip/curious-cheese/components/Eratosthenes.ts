import { Subject } from './Subject'; //Sieb
import { Observer } from './Observer'; //UI

export class Eratosthenes implements Subject {
  private upperSize: number; //speichert die obere Grenze der Siebgröße
  private primes: boolean[]; //boolesches Array, das die Primzahlen speichert
  private observers: Observer[] = []; //Array von Observers die, die informiert werden sollen, wenn sich das primes-Array ändert


  public constructor(upperSize: number) {
    this.upperSize = upperSize; //obere Grenze upperSize als Argument
    this.primes = new Array(upperSize + 1).fill(true); //das primes-Array wird mit true-Werten gefüllt,"+1" -> die Zahl "upperSize"
  }

  public runSieve(): number[] { //implementiert den eigentlichen Siebalgorithmus 
    const primesList: number[] = []; //leeres Array -> gibt dann ein Array von Primzahlen zurück

    for (let i = 2; i <= Math.sqrt(this.upperSize); i++) { //das Sieb startet bei der Zahl 2, da 1 keine Primzahl ist
      if (this.primes[i]) { //Schleife über alle Zahlen von 2 bis zur Wurzel der oberen Grenze upperSize durchlaufen
        for (let j = i * i; j <= this.upperSize; j += i) { //wird geprüft, ob sie im primes-Array als Primzahl markiert ist
          this.primes[j] = false; //alle Vielfachen dieser Zahl im primes-Array auf false gesetzt --> kein Primzahl
        }
      }
    }

    for (let i = 2; i <= this.upperSize; i++) { //weitere Schleife über alle Zahlen von 2 bis zur oberen Grenze upperSize
      if (this.primes[i]) { //wird geprüft, ob sie im primes-Array als Primzahl markiert ist
        primesList.push(i); //wird die Zahl dem Array primesList hinzugefügt
      }
    }

    return primesList; //Array primesList zurückgegeben
  }

  public attach(observer: Observer): void { //fügt einen Observer der Liste von Observers
    this.observers.push(observer);
  }

  public detach(observer: Observer): void { //entfernt einen Observer aus der Liste von Observers
    const index = this.observers.indexOf(observer);
    if (index !== -1) {
      this.observers.splice(index, 1);
    }
  }

  public notify(): void { //iteriert durch die Liste von Observers
    const primes = this.primes;
    const primeString = primes.join(', ');
    this.observers.forEach((observer) => observer.update(primeString)); //und ruft deren update()-Methode auf, um sie über Änderungen zu informieren
  }

}

//zum Überprüfen: eine Liste von Primzahlen zu erzeugen und auszugeben

/*const eratosthenes = new Eratosthenes(1000);
const primes = eratosthenes.runSieve();
console.log(primes);*/