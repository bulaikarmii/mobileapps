import * as React from 'react';
import { useState } from 'react';
import { Observer } from './Observer';
import { Eratosthenes } from './Eratosthenes';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

//Hauptfunktion

export default function EratosthenesApp() {  //mehrere Zustände deklariert: useState -> jeden Zustand zu initialisieren und eine aktualisierte Version davon beim Ändern eines Zustands zu erhalten
  const [upperLimit, setUpperLimit] = useState<string>('');
  const [primes, setPrimes] = useState<number[]>([]);
  const [observers, setObservers] = useState<Observer[]>([]);
  const [errorMessage, setErrorMessage] = useState<string>('');

  //ab hier: Hilfsfunktionen innerhalb der Hauptfunktion

  const calculatePrimes = () => {
    const eratosthenes = new Eratosthenes(parseInt(upperLimit)); //ruft eine neue Instanz von "Eratosthenes" auf
    const newPrimes = eratosthenes.runSieve(); //berechnet die Primzahlen mit der Methode "runSieve"
    setPrimes(newPrimes); //aktualisiert den Zustand "primes"
    notifyObservers(); //ruft die "update"-Methode für jeden Observer auf und übergibt die aktualisierte Liste der Primzahlen
  };

  const notifyObservers = () => { //benachrichtigt alle Observer über die aktuellen Primzahlen
    observers.forEach((observer) => {
      observer.update(JSON.stringify(primes)); //enthält die aktualisierte Liste von primes der Primzahlen als JSON-String
    });
  };

  const handleInputChange = (text: string) => {
    setUpperLimit(text); //aktualisiert den Zustand "upperLimit" mit dem vom Benutzer eingegebenen Wert
    setPrimes([]); //setzt auch den Zustand "primes" auf eine leere Liste zurück
    setErrorMessage('');
  };

  const handleSubmit = () => { //klicken auf Calculate
    calculatePrimes(); //ruft die "calculatePrimes"-Methode auf
  };

  //Titelbereich, Eingabebereich für die obere Grenze, Schaltfläche, Ergebnisbereich 

  return (
    <View style={[styles.container, { marginTop: 30 }]}>
      <View style={styles.titleContainer}>
        <Text style={styles.title}>Sieve of Eratosthenes</Text>
      </View>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Specify the upper limit.."
          placeholderTextColor="#FFFFFF"
          value={upperLimit}
          onChangeText={handleInputChange}
        />
        <TouchableOpacity onPress={handleSubmit} style={styles.button}>
          <Text style={styles.buttonText}>Calculate</Text>
        </TouchableOpacity>
      </View>
      <ScrollView style={styles.resultContainer}>
        <Text style={styles.resultTitle}>Result:</Text>
        {primes.map((prime, index) => (
          <View key={index} style={styles.resultItemContainer}>
            <Text style={styles.resultItem}>{prime}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

//Aussehen der Komponente

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1E1E1E',
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingTop: 30,
    paddingHorizontal: 20,
    paddingBottom: 30,
  },
  titleContainer: {
    marginBottom: 20,
  },
  title: {
    color: 'white',
    fontFamily: 'Satoshi',
    fontWeight: 'bold',
    fontSize: 32,
    textAlign: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
    width: '100%',
  },
  input: {
    color: 'white',
    fontFamily: 'Satoshi',
    fontSize: 18,
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 15,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    flex: 1,
  },
  button: {
    fontFamily: 'Satoshi',
    backgroundColor: '#555555',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 15,
    marginLeft: 10,
  },
  buttonText: {
    fontFamily: 'Satoshi',
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
    textAlign: 'center',
  },
  resultContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 15,
    flex: 1,
    width: '100%',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    alignItems: 'center',
  },
  resultTitle: {
    color: '#555555',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
    //color: 'white',
  },
  resultItemContainer: {
    backgroundColor: '#555555',
    borderRadius: 15,
    padding: 3,
    margin: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },


  resultItem: {
    color: 'white',
    fontSize: 16,
    fontFamily: 'Satoshi',
  },

});