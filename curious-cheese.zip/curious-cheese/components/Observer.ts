
export interface Observer
{
  update(primes : string) : void;
}