import * as React from 'react';
import EratosthenesApp from './components/EratosthenesApp';
//import Eratosthenes from './components/Eratosthenes';

/*export default function App() 
{
  let era_app = new EratosthenesApp();
  
  return era_app;
}*/

export default class App extends React.Component
{
  render()
  {
    return (<EratosthenesApp/>);
  }
}
