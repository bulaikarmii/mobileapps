import * as React from 'react';
import Calculator from './components/Calculator.tsx';

const App = () => {
  return (
    <Calculator />
  );
};

export default App;
