import React, { useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';

type Operation = '+' | '-' | '*' | '/'; //Typalias für mögliche arithmetische Operationen

//Hauptkomponente der Anwendung

export default function App() {
  const [operands, setOperands] = useState<string[]>(['0']); //Speichert die Zahlen, die vom Benutzer eingegeben wurden
  const [operations, setOperations] = useState<Operation[]>([]); //Speichert die Operationen, die vom Benutzer gewählt wurden
  const [, setPreviousResult] = useState<number | null>(null); //Speichert das vorherige Berechnungsergebnis
  const [lastInputIsOperation, setLastInputIsOperation] = //Ein Boolean, der angibt, ob die letzte Eingabe eine Operation war, um zu verhindern, dass zwei Operationen nacheinander eingegeben werden
    useState<boolean>(false);

//Funktionen zur Behandlung der Interaktionen

//Fügt eine Operation zum operations-Zustand hinzu und fügt eine leere Zeichenfolge zum operands-Zustand hinzu

  const handleOperation = (op: Operation) => { 
    if (lastInputIsOperation) return;
    setLastInputIsOperation(true);
    setOperations((prevOperations) => [...prevOperations, op]);
    setOperands((prevOperands) => [...prevOperands, '']);
  };

//Berechnet das Ergebnis basierend auf den Operanden und Operationen. Es implementiert die Grundrechenarten und berücksichtigt die richtige Reihenfolge der Operationen (Multiplikation und Division vor Addition und Subtraktion)

  const handleCalculate = () => { 
    if (operands.length < 2 || operations.length < 1) {
      return;
    }

    const newOperands = operands.slice();
    const newOperations = operations.slice();

    for (let i = 0; i < newOperations.length;) {
      const op = newOperations[i];
      if (op === '*' || op === '/') {
        const leftOperand = Number(newOperands[i]);
        const rightOperand = Number(newOperands[i + 1]);
        let res;
        if (op === '*') {
          res = leftOperand * rightOperand;
        } else {
          res = leftOperand / rightOperand;
        }
        newOperands.splice(i, 2, res.toString());
        newOperations.splice(i, 1);
      } else {
        i++;
      }
    }

    let res = Number(newOperands[0]);
    for (let i = 0; i < newOperations.length; i++) {
      const op = newOperations[i];
      const operand = Number(newOperands[i + 1]);
      if (op === '+') {
        res += operand;
      } else if (op === '-') {
        res -= operand;
      } else {
        return;
      }
    }

    setPreviousResult(res);
    setOperands([res.toString()]);
    setOperations([]);
  };

  const defaultOperand = '0';

//Setzt alle Zustände zurück auf ihre Anfangswerte

  const handleClear = () => {
    setLastInputIsOperation(false);
    setOperands([defaultOperand]);
    setOperations([]);
    setPreviousResult(null);
  };

//Wandelt den letzten Operanden in einen Prozentsatz um

  const handlePercentage = () => {
    if (operands.length < 1) return;
    const lastOperand = Number(operands[operands.length - 1]);
    const percentage = lastOperand / 100;
    setOperands([...operands.slice(0, -1), percentage.toString()]);
    setLastInputIsOperation(false);
  };

//Fügt eine Nummer zum letzten Operanden hinzu

  const handleNumberPress = (num) => {
    setLastInputIsOperation(false);
    const lastOperand = operands[operands.length - 1];
    if (lastOperand === '0' && num === '0') {
      return;
    }
    if (lastOperand === '0' && num !== '0') {
      setOperands([...operands.slice(0, -1), num]);
    } else {
      setOperands([...operands.slice(0, -1), lastOperand + num]);
    }
    setPreviousResult(null);
  };

//Fügt einen Dezimalpunkt zum letzten Operanden hinzu, wenn er noch keinen hat

  const handleDecimalPress = () => {
    setLastInputIsOperation(false);
    const lastOperand = operands[operands.length - 1];
    if (!lastOperand || lastOperand.includes('.')) {
      return;
    }
    setOperands([...operands.slice(0, -1), `${lastOperand}.`]);
  };

  const expression = operands
    .map((operand, index) => `${operand}${operations[index] || ''}`)
    .join('');

//Löscht die letzte Eingabe des Benutzers

  const handleDelete = () => {
    const lastInput = operands[operands.length - 1];
    const lastOperation = operations[operations.length - 1];

    // Löschen der letzten arithmetischen Operation oder der Zahl vor der Operation
    if (lastInput === '' && lastOperation) {
      const lastNonEmptyInput = findLastNonEmptyInput();
      if (lastNonEmptyInput === '+') {
        setOperations(operations.slice(0, -2));
        setOperands(operands.slice(0, -1));
      } else if (
        lastNonEmptyInput === '-' ||
        lastNonEmptyInput === '*' ||
        lastNonEmptyInput === '/'
      ) {
        setOperations(operations.slice(0, -1));
        setOperands([...operands.slice(0, -2), lastNonEmptyInput, '']);
      } else {
        setOperations(operations.slice(0, -1));
        setOperands(operands.slice(0, -1));
      }
      setLastInputIsOperation(true);
    }
    // Löschen der letzten Zahl
    else if (lastInput.length === 1 && !lastOperation) {
      if (operands.length > 1) {
        setOperands(operands.slice(0, -1));
      } else {
        setOperands([defaultOperand]);
      }
      setLastInputIsOperation(true);
    }
    // Löschen eines einzelnen arithmetischen Zeichens innerhalb einer Zahl
    else {
      const newOperand = lastInput.slice(0, -1);
      setOperands([...operands.slice(0, -1), newOperand]);
      setLastInputIsOperation(false);
    }
  };

  const findLastNonEmptyInput = () => {
    const reversedInputs = operands
      .slice(0, operands.length - 1)
      .reverse()
      .join('');
    const match = reversedInputs.match(/[\d\.]+|[-+*/]/);
    if (match) {
      return match[0];
    } else {
      return '';
    }
  };

//Darstellung der Benutzeroberfläche

  return (
    <View style={styles.container}>
      <View style={styles.display}>
        <Text style={styles.expression}>{expression}</Text>
      </View>
      <View style={styles.buttons}>
        <View style={styles.row}>
          <TouchableOpacity style={styles.button2} onPress={handleClear}>
            <Text style={[styles.text, { color: '#FBAF04' }]}>C</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button2} onPress={handleDelete}>
            <Text style={[styles.text, { color: '#FBAF04' }]}>D</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.button2} onPress={handlePercentage}>
            <Text style={[styles.text, { color: '#FBAF04' }]}>%</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.button2}
            onPress={() => handleOperation('/')}>
            <Text style={[styles.text, { color: '#FBAF04' }]}>/</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.row}>
          <TouchableOpacity
            style={styles.button}
            onPress={() => handleNumberPress('7')}>
            <Text style={styles.text}>7</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.button}
            onPress={() => handleNumberPress('8')}>
            <Text style={styles.text}>8</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.button}
            onPress={() => handleNumberPress('9')}>
            <Text style={styles.text}>9</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.button2}
            onPress={() => handleOperation('*')}>
            <Text style={[styles.text, { color: '#FBAF04' }]}>x</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.row}>
          <TouchableOpacity
            style={styles.button}
            onPress={() => handleNumberPress('4')}>
            <Text style={styles.text}>4</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.button}
            onPress={() => handleNumberPress('5')}>
            <Text style={styles.text}>5</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.button}
            onPress={() => handleNumberPress('6')}>
            <Text style={styles.text}>6</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.button2}
            onPress={() => handleOperation('-')}>
            <Text style={[styles.text, { color: '#FBAF04' }]}>-</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.row}>
          <TouchableOpacity
            style={styles.button}
            onPress={() => handleNumberPress('1')}>
            <Text style={styles.text}>1</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.button}
            onPress={() => handleNumberPress('2')}>
            <Text style={styles.text}>2</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.button}
            onPress={() => handleNumberPress('3')}>
            <Text style={styles.text}>3</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.button2}
            onPress={() => handleOperation('+')}>
            <Text style={[styles.text, { color: '#FBAF04' }]}>+</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.row}>
          <TouchableOpacity
            style={styles.button}
            onPress={() => handleNumberPress('0')}>
            <Text style={styles.text}>0</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={handleDecimalPress}>
            <Text style={styles.text}>.</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button3} onPress={handleCalculate}>
            <Text style={[styles.text, { color: '#1F1F1F' }]}>=</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1A1A1A',
  },
  display: {
    flex: 2,
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
    padding: 20,
    backgroundColor: '#1A1A1A',
  },
  buttons: {
    flex: 3,
    backgroundColor: '#1E1E1E',
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 16,
    boxShadow: '0 2px 5px rgba(255, 255, 255, 0.7)',
    outline: '1px solid rgba(0, 0, 0, 0.1)',
    elevation: 20
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingVertical: 10,
  },
  button: {
    backgroundColor: '#1F1F1F',
    borderRadius: 40,
    width: 70,
    height: 70,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 16,
    boxShadow: '0 2px 5px rgba(255, 255, 255, 0.7)',
    outline: '1px solid rgba(0, 0, 0, 0.1)',
    elevation: 20
  },
  button2: {
    backgroundColor: '#1F1F1F',
    borderRadius: 40,
    width: 70,
    height: 70,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 16,
    boxShadow: '0 2px 5px rgba(255, 255, 255, 0.7)',
    outline: '1px solid rgba(0, 0, 0, 0.1)',
    elevation: 20
  },
  button3: {
    backgroundColor: '#FBAF04',
    borderRadius: 40,
    width: 165,
    height: 70,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 16,
    boxShadow: '0 2px 5px rgba(255, 255, 255, 0.7)',
    outline: '1px solid rgba(0, 0, 0, 0.1)',
    elevation: 20
  },
  text: {
    fontSize: 28,
    color: 'rgba(255, 255, 255, 1)',
    fontFamily: 'Satoshi',
  },
  expression: {
    fontSize: 48,
    fontFamily: 'Satoshi',
    marginBottom: 10,
    color: 'rgba(255, 255, 255, 0.8)',
  },
});